﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        //  Login button clicked
        private void AcceptButton_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (username == "home")
            {
                if (password == "1234")
                {

                    this.Visible = false;
                    Form2 frm2 = new Form2();
                    frm2.ShowDialog();
                } else
                {
                    MessageBox.Show("Invalid Username or Password. Please try again.");
                }
            } 
            }
        }
        
    }

