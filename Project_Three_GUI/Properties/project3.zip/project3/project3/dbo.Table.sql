﻿CREATE TABLE [dbo].[Table]
(
	[userId] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [password] VARCHAR(50) NOT NULL
)
