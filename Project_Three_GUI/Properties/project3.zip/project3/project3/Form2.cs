﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using MySql.Data.MySqlClient;

namespace project3
{
    public partial class Form2 : Form
    {

        private MySqlConnection connection;
        private string server;
        private string database;
        private string user;
        private string password;
        private string port;
        private string connectionString;
        private string sslM;



        public Form2()
        {
            InitializeComponent();
            credentialBoxes.Visible = false;

            server = "csharp.c4jvxcqwrkqd.us-east-2.rds.amazonaws.com";
            database = "Students";
            user = "root";
            password = "root123456";
            port = "3306";
            sslM = "none";

            connectionString = String.Format("server={0};port={1};user id={2}; password={3}; database={4}; SslMode={5}", server, port, user, password, database, sslM);

            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();

                MessageBox.Show("You are now logged in!");

                connection.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message + connectionString);
            }

            
            MySqlDataReader reader = null;
            string query = "SELECT * FROM Students";

            MySqlCommand command = new MySqlCommand(query, connection);
            connection.Open();
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                string id = reader["id"].ToString();
                string name = reader["Name"].ToString();
                string Email = reader["Email"].ToString();
                string Phone = reader["Phone"].ToString();
                Console.WriteLine(id);
                //  Create Each Row Here

            }
            connection.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (credentialBoxes.Visible == false)
            {
                credentialBoxes.Visible = true;
            } else
            {
                credentialBoxes.Visible = false;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MySqlCommand comm = connection.CreateCommand();
            connection.Open();
            comm.CommandText = "INSERT INTO Students(Name,Email,Phone) VALUES(@name, @email, @phone)";
            comm.Parameters.AddWithValue("@name", fName.Text);
            comm.Parameters.AddWithValue("@email", Email.Text);
            comm.Parameters.AddWithValue("@phone", pNumber.Text);
            comm.ExecuteNonQuery();

            fName.Text = "";
            Email.Text = "";
            pNumber.Text = "";

            MessageBox.Show("Student Added!");

            connection.Close();
        }

        private void pNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
